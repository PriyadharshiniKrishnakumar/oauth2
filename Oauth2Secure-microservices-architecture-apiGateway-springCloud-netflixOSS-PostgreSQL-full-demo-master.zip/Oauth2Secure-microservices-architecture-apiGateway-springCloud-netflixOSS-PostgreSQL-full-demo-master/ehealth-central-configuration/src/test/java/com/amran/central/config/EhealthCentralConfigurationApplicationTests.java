package com.amran.central.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EhealthCentralConfigurationApplicationTests {

    @Test
    void contextLoads() {
    }

}

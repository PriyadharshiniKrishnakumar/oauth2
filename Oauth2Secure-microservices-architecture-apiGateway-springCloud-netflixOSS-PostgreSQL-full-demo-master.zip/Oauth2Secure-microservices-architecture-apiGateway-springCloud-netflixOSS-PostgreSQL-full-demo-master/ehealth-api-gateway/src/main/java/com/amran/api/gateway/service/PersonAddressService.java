package com.amran.api.gateway.service;

/**
 * @Author : Amran Hosssain on 6/24/2020
 */
public interface PersonAddressService {
}

package com.amran.patient.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientManagementServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
